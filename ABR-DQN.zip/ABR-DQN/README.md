# ABR-DQN
Adaptive bitrate (ABR) video streaming is one of the main applications for providing higher video services on all network conditions. 
In this work, we use Deep Q-learning method to genreate an ABR alogrithm. Meanwhile, we package the Pensieve environments to a simple gym.
 Results show that ABR algorithm which DQN generates also performs well in various network conditions.

In this sample, please type 'python main.py' to run and enjoy.

Cooked_traces: training data
test.csv: testing data
To train model with new data, please copy new data to cooked_traces for training
 and then make another file of test.csv for testing
