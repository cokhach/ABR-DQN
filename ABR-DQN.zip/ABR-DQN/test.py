# -*- coding: utf-8 -*-
"""
Created on Sat Sep 11 18:41:28 2021

@author: nguyen tuan
"""

import gym
import gym_abr

env = gym.make('gym_abr:ABR-v0')